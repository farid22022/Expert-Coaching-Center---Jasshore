import { MailSmsPageShell } from "../mailSmsShared.jsx";

export function ContactCategoryCreatePage() {
  return <MailSmsPageShell title="Contact Category Create" />;
}

export function ContactCategoryListPage() {
  return <MailSmsPageShell title="Contact Category List" />;
}
