import { MailSmsPageShell } from "../mailSmsShared.jsx";

export function SmsApiCreatePage() {
  return <MailSmsPageShell title="SMS API Create" />;
}

export function SmsApiListPage() {
  return <MailSmsPageShell title="SMS API List" />;
}
