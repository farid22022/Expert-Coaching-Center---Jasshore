import { MailSmsPageShell } from "../mailSmsShared.jsx";

export function StudentSmsListPage() {
  return <MailSmsPageShell title="Student SMS List" />;
}

export function StudentAdmissionOnlinePage() {
  return <MailSmsPageShell title="Student Admission Online" />;
}

export function StudentAdmissionSoftwarePage() {
  return <MailSmsPageShell title="Student Admission Software" />;
}

export function StudentAttendanceSmsCreatePage() {
  return <MailSmsPageShell title="Student Attendance SMS Create" />;
}

export function StudentAbsentSmsCreatePage() {
  return <MailSmsPageShell title="Student Absent SMS Create" />;
}

export function StudentFeesCollectionSmsCreatePage() {
  return <MailSmsPageShell title="Student Fees Collection SMS Create" />;
}

export function StudentDueFeesSmsCreatePage() {
  return <MailSmsPageShell title="Student Due Fees SMS Create" />;
}

export function SubjectWiseResultSmsPage() {
  return <MailSmsPageShell title="Subject Wise Result SMS" />;
}

export function ResultSmsPage() {
  return <MailSmsPageShell title="Result SMS" />;
}
