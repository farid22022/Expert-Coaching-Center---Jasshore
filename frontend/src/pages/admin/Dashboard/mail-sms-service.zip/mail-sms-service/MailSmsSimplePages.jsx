import { MailSmsPageShell } from "./mailSmsShared.jsx";

export function SmsMailSetupPage() {
  return <MailSmsPageShell title="SMS/Mail Setup" />;
}

export function SmsMailTemplatePage() {
  return <MailSmsPageShell title="SMS/Mail Template" />;
}
