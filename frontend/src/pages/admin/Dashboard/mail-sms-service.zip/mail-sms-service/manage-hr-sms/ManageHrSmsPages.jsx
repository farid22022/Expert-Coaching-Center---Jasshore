import { MailSmsPageShell } from "../mailSmsShared.jsx";

export function TeacherEmployeeSmsListPage() {
  return <MailSmsPageShell title="Teacher/Employee SMS List" />;
}

export function TeacherEmployeeJoiningSmsCreatePage() {
  return <MailSmsPageShell title="Teacher/Employee Joining SMS Create" />;
}

export function TeacherEmployeeAttendanceSmsCreatePage() {
  return <MailSmsPageShell title="Teacher/Employee Attendance SMS Create" />;
}

export function TeacherEmployeeAbsentSmsCreatePage() {
  return <MailSmsPageShell title="Teacher/Employee Absent SMS Create" />;
}

export function TeacherEmployeeSalarySmsCreatePage() {
  return <MailSmsPageShell title="Teacher/Employee Salary SMS Create" />;
}
