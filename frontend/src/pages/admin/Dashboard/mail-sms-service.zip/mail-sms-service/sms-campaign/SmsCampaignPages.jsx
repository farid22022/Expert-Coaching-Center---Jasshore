import { MailSmsPageShell } from "../mailSmsShared.jsx";

export function SmsCampaignCreatePage() {
  return <MailSmsPageShell title="SMS Campaign Create" />;
}

export function SmsReportListPage() {
  return <MailSmsPageShell title="SMS Report List" />;
}

export function SmsReportSearchPage() {
  return <MailSmsPageShell title="SMS Report Search" />;
}

export function SmsCampaignOrganizationPage() {
  return <MailSmsPageShell title="SMS Campaign Organization" />;
}
