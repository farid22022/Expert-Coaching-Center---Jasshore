import { Link } from "react-router-dom";
import { institution } from "../../data/site.js";

const cols = [
  ["Institution", [["About", "/about/history"], ["History", "/about/history"], ["Teachers", "/about/teachers"], ["Contact", "/contact"]]],
  ["Academic", [["Student List", "/academic/students"], ["Class Routine", "/academic/class-routine"], ["Exam Routine", "/academic/exam-routine"], ["Results", "/result/individual"]]],
  ["Admission", [["Online Admission", "/admission/online"], ["Admission Result", "/admission/result"], ["Admit Card", "/admission/admit-card"]]],
  ["Important", [["Notices", "/notices"], ["News", "/news"], ["Events", "/events"], ["Gallery", "/gallery/photos"]]],
];

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        {cols.map(([title, links]) => <div key={title}><h3>{title}</h3>{links.map(([label, path]) => <Link key={path + label} to={path}>{label}</Link>)}</div>)}
        <div><h3>Contact</h3><p>{institution.address}</p><p>{institution.phone}</p><p>{institution.email}</p></div>
      </div>
      <div className="copyright">© {new Date().getFullYear()} {institution.name}. Public website clone.</div>
    </footer>
  );
}
