import { Link, NavLink } from "react-router-dom";
import { useState } from "react";
import { Menu, Search, X, ChevronDown, Phone, Mail } from "lucide-react";
import { institution, navGroups } from "../../data/site.js";

export default function Header() {
  const [mobile, setMobile] = useState(false);
  const [open, setOpen] = useState("");
  const nav = <nav className="nav" aria-label="Main navigation">{navGroups.map((group) => group.items ? (
    <div className="nav-group" key={group.label}>
      <button onClick={() => setOpen(open === group.label ? "" : group.label)} aria-expanded={open === group.label}>{group.label}<ChevronDown size={15} /></button>
      <div className={`dropdown ${open === group.label ? "show" : ""}`}>{group.items.map(([label, path]) => <NavLink key={path} to={path} onClick={() => setMobile(false)}>{label}</NavLink>)}</div>
    </div>
  ) : <NavLink key={group.path} to={group.path} onClick={() => setMobile(false)}>{group.label}</NavLink>)}</nav>;

  return (
    <header className="site-header">
      <div className="topbar"><span><Phone size={14} />{institution.phone}</span><span><Mail size={14} />{institution.email}</span></div>
      <div className="container header-main">
        <Link className="brand" to="/"><span className="logo">ECC</span><span><strong>{institution.name}</strong><small>{institution.address}<br />ESTD : {institution.established}</small></span></Link>
        <div className="desktop-nav">{nav}<Link className="search-link" to="/search"><Search size={18} /></Link></div>
        <button className="hamburger" onClick={() => setMobile(!mobile)} aria-label="Open menu">{mobile ? <X /> : <Menu />}</button>
      </div>
      {mobile && <div className="mobile-panel">{nav}<Link to="/search" onClick={() => setMobile(false)}>Search</Link></div>}
    </header>
  );
}
