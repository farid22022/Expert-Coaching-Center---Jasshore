import { Link } from "react-router-dom";

export default function PageHeader({ title, eyebrow, description }) {
  return (
    <section className="page-header">
      <div className="container">
        <div className="breadcrumb"><Link to="/">Home</Link><span>/</span><span>{title}</span></div>
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
    </section>
  );
}
