export function TeacherCard({ teacher }) {
  return (
    <article className="card profile-card">
      <img src={teacher.image} alt={teacher.name} />
      <div><h3>{teacher.name}</h3><p className="badge">{teacher.designation}</p><p>{teacher.subject}</p><small>{teacher.bio}</small></div>
    </article>
  );
}

export function InfoCard({ title, children, icon }) {
  return <article className="card info-card"><div className="icon">{icon}</div><h3>{title}</h3><div>{children}</div></article>;
}
