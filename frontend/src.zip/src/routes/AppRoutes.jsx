import { Routes, Route } from "react-router-dom";
import Home from "../pages/Home.jsx";
import { AboutText, ProfilePage, TeachersPage } from "../pages/AboutPages.jsx";
import { StudentsPage, ClassRoutinePage, ExamRoutinePage, RulesPage, UniformPage, HolidaysPage } from "../pages/AcademicPages.jsx";
import { IndividualResultPage, AssessmentPage, BoardResultPage } from "../pages/ResultPages.jsx";
import { OnlineAdmissionPage, AdmissionResultPage, BlankFormPage, ApplicantPage, AdmitCardPage } from "../pages/AdmissionPages.jsx";
import { ListingPage, DetailPage } from "../pages/ContentPages.jsx";
import { PhotoGalleryPage, VideoGalleryPage } from "../pages/GalleryPages.jsx";
import Contact from "../pages/Contact.jsx";
import SearchPage from "../pages/SearchPage.jsx";
import UtilityPage, { NotFound } from "../pages/UtilityPage.jsx";

export default function AppRoutes() {
  return <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/about/history" element={<AboutText type="history" />} />
    <Route path="/about/founder" element={<ProfilePage type="founder" />} />
    <Route path="/about/chairman" element={<ProfilePage type="chairman" />} />
    <Route path="/about/principal" element={<ProfilePage type="principal" />} />
    <Route path="/about/teachers" element={<TeachersPage />} />
    <Route path="/about/committee" element={<AboutText type="committee" />} />
    <Route path="/about/staff" element={<AboutText type="staff" />} />
    <Route path="/about/institution-details" element={<AboutText type="institution-details" />} />
    <Route path="/academic/students" element={<StudentsPage />} />
    <Route path="/academic/class-routine" element={<ClassRoutinePage />} />
    <Route path="/academic/exam-routine" element={<ExamRoutinePage />} />
    <Route path="/academic/rules" element={<RulesPage />} />
    <Route path="/academic/uniform" element={<UniformPage />} />
    <Route path="/academic/holidays" element={<HolidaysPage />} />
    <Route path="/result/individual" element={<IndividualResultPage />} />
    <Route path="/result/assessment" element={<AssessmentPage />} />
    <Route path="/result/board" element={<BoardResultPage />} />
    <Route path="/admission/online" element={<OnlineAdmissionPage />} />
    <Route path="/admission/result" element={<AdmissionResultPage />} />
    <Route path="/admission/form" element={<BlankFormPage />} />
    <Route path="/admission/applicant" element={<ApplicantPage />} />
    <Route path="/admission/admit-card" element={<AdmitCardPage />} />
    <Route path="/notices" element={<ListingPage type="notices" title="Notices" />} />
    <Route path="/notices/:id" element={<DetailPage type="notices" title="Notices" />} />
    <Route path="/news" element={<ListingPage type="news" title="News" />} />
    <Route path="/news/:id" element={<DetailPage type="news" title="News" />} />
    <Route path="/events" element={<ListingPage type="events" title="Events" />} />
    <Route path="/events/:id" element={<DetailPage type="events" title="Events" />} />
    <Route path="/gallery/photos" element={<PhotoGalleryPage />} />
    <Route path="/gallery/videos" element={<VideoGalleryPage />} />
    <Route path="/contact" element={<Contact />} />
    <Route path="/search" element={<SearchPage />} />
    {["attendance","due-report","digital-content","boys-scout","student-statistics","nctb-books"].map((p) => <Route key={p} path={`/${p}`} element={<UtilityPage title={p.split("-").map((x) => x[0].toUpperCase() + x.slice(1)).join(" ")} />} />)}
    <Route path="*" element={<NotFound />} />
  </Routes>;
}
