import { useState } from "react";
import PageHeader from "../components/common/PageHeader.jsx";
import SEO from "../components/common/SEO.jsx";
import { admissionService } from "../services/api.js";

const sections = {
  "Student Information": ["Full Name","Bengali Name","Blood Group","Student UID","Mobile","Email","Date of Birth","Birth Certificate Number","Religion","Gender","Country","Student Photograph"],
  "Father Information": ["Father Name","Father Bengali Name","Father Mobile","Father NID","Father Date of Birth","Father Profession"],
  "Mother Information": ["Mother Name","Mother Bengali Name","Mother Mobile","Mother NID","Mother Date of Birth","Mother Profession"],
  Guardian: ["Guardian Name","Guardian Mobile","Relationship"],
  "Academic Information": ["Category","Session","Shift","Class","Section","Group","Roll","Version","Register Number","Student ID","Admission Date"],
  "Previous Institution": ["Previous School Name","Previous Class","Previous Roll"],
  Payment: ["Payment Method","Amount","Sender Number","Transaction Number","Transaction ID"],
};

export function OnlineAdmissionPage() {
  const [submitted, setSubmitted] = useState(null);
  async function submit(e) { e.preventDefault(); const data = Object.fromEntries(new FormData(e.currentTarget)); setSubmitted(await admissionService.submit(data)); }
  return <><SEO title="Online Admission" /><PageHeader title="Online Admission" eyebrow="Admission" description="Mock admission submission with printable application preview." /><section className="section"><div className="container"><form className="admission-form" onSubmit={submit}>{Object.entries(sections).map(([title, fields]) => <fieldset key={title}><legend>{title}</legend><div className="form-grid">{fields.map((f) => <label key={f}>{f}<input required={["Full Name","Mobile","Class"].includes(f)} name={f} type={f.includes("Date") ? "date" : "text"} /></label>)}</div></fieldset>)}<button className="btn primary">Submit Application</button></form>{submitted && <div className="success printable"><h2>Application Submitted</h2><p>Reference: <strong>{submitted.applicationId}</strong></p><button className="btn no-print" onClick={() => window.print()}>Print Application</button></div>}</div></section></>;
}
export function AdmissionResultPage() { return <SearchStatus title="Admission Result" fields={["Application ID","Mobile Number"]} />; }
export function ApplicantPage() { return <SearchStatus title="Applicant's Form" fields={["Application ID","Mobile","Name"]} />; }
function SearchStatus({ title, fields }) {
  const [status, setStatus] = useState(null);
  return <><SEO title={title} /><PageHeader title={title} eyebrow="Admission" /><section className="section"><div className="container"><div className="form-grid">{fields.map((f) => <label key={f}>{f}<input /></label>)}<button className="btn primary" onClick={async () => setStatus(await admissionService.status())}>Search</button></div>{status && <div className="card"><h2>{status.name}</h2><p>Application: {status.applicationId}</p><p className="badge">{status.status}</p></div>}</div></section></>;
}
export function BlankFormPage() { return <PrintableDoc title="Blank Admission Form" lines={["Student information","Parent information","Academic information","Guardian information","Photograph area","Applicant and guardian signatures"]} />; }
export function AdmitCardPage() { return <PrintableDoc title="Admit Card" search lines={["Institution logo and name","Student photo and name","Roll, class, exam, venue","Subject-wise exam dates","Authorized signature"]} />; }
function PrintableDoc({ title, lines, search }) {
  return <><SEO title={title} /><PageHeader title={title} eyebrow="Admission" /><section className="section printable"><div className="container">{search && <div className="form-grid no-print"><label>Student ID<input /></label><label>Roll<input /></label><label>Application ID<input /></label><button className="btn primary">Search</button></div>}<div className="print-doc"><h2>{title}</h2>{lines.map((l) => <p key={l}>{l}</p>)}<div className="signature-row"><span>Applicant Signature</span><span>Guardian Signature</span><span>Authority</span></div></div><button className="btn no-print" onClick={() => window.print()}>Print</button></div></section></>;
}
