import { useState } from "react";
import PageHeader from "../components/common/PageHeader.jsx";
import SEO from "../components/common/SEO.jsx";
import { photos, videos } from "../data/mockData.js";

export function PhotoGalleryPage() {
  const [active, setActive] = useState(null);
  return <><SEO title="Photo Gallery" /><PageHeader title="Photo Gallery" eyebrow="Gallery" /><section className="section"><div className="container gallery-grid">{photos.map((p) => <button className="photo-button" key={p.id} onClick={() => setActive(p)}><img src={p.src} alt={p.title} /><span>{p.title}</span></button>)}</div></section>{active && <div className="lightbox" role="dialog"><button onClick={() => setActive(null)}>Close</button><img src={active.src} alt={active.title} /><h2>{active.title}</h2></div>}</>;
}
export function VideoGalleryPage() {
  return <><SEO title="Video Gallery" /><PageHeader title="Video Gallery" eyebrow="Gallery" /><section className="section"><div className="container card-grid">{videos.map((v) => <article className="card" key={v.id}><iframe src={v.url} title={v.title} allowFullScreen /><h2>{v.title}</h2><p>{v.description}</p></article>)}</div></section></>;
}
