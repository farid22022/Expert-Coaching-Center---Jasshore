import { Link } from "react-router-dom";
import { BookOpen, ClipboardList, GraduationCap, Users } from "lucide-react";
import SEO from "../components/common/SEO.jsx";
import { TeacherCard, InfoCard } from "../components/common/Cards.jsx";
import { institution, quickLinks, studentCorner } from "../data/site.js";
import { teachers, notices, news, photos } from "../data/mockData.js";

export default function Home() {
  return (
    <>
      <SEO title="Home" description="Public website for Expert Coaching Center, Jashore." />
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <p className="eyebrow">Stadium Road, Jashore • ESTD {institution.established}</p>
            <h1>{institution.name}</h1>
            <p>Academic coaching, assessment, admission, routine, result, notice, and student support portal for learners and guardians.</p>
            <div className="actions"><Link className="btn primary" to="/admission/online">Online Admission</Link><Link className="btn" to="/result/individual">Student Result</Link><Link className="btn ghost" to="/notices">Notice Board</Link></div>
          </div>
          <div className="hero-card"><h2>Latest Notices</h2>{notices.map((n) => <Link key={n.id} to={`/notices/${n.id}`}><span>{n.date}</span>{n.title}</Link>)}</div>
        </div>
      </section>
      <section className="section"><div className="container"><h2>রিপোর্ট কর্নার</h2><div className="quick-grid">{quickLinks.map(([label, path]) => <Link className="quick-card" key={path} to={path}><ClipboardList />{label}</Link>)}</div></div></section>
      <section className="section muted"><div className="container split"><div><p className="eyebrow">Institution Introduction</p><h2>{institution.name}</h2><p>Founded in {institution.established}, Expert Coaching Center supports students in Jashore with structured classes, regular evaluation, guardian communication, and disciplined academic preparation.</p><Link className="btn primary" to="/about/history">Read More</Link></div><div className="stats"><InfoCard title="Students" icon={<GraduationCap />}>Mock public statistics and searchable student list.</InfoCard><InfoCard title="Teachers" icon={<Users />}>Experienced subject teachers and academic mentors.</InfoCard><InfoCard title="Academic" icon={<BookOpen />}>Routine, exam, rules, holidays, and results.</InfoCard></div></div></section>
      <section className="section"><div className="container"><h2>প্রতিষ্ঠাতার বাণী</h2><div className="message"><img src="https://placehold.co/180x210/e8f2ee/173d33?text=Director" alt="Director" /><div><h3>নামঃ {institution.founderBn}</h3><p>পদবীঃ পরিচালক</p><p>We aim to create a careful, student-first coaching environment with regular feedback and transparent academic support.</p></div></div></div></section>
      <section className="section muted"><div className="container"><h2>সম্মানিত শিক্ষক বৃন্দের তালিকা</h2><div className="card-grid">{teachers.slice(0, 6).map((t) => <TeacherCard key={t.id} teacher={t} />)}</div><Link className="text-link" to="/about/teachers">View all teachers</Link></div></section>
      <section className="section"><div className="container two-cols"><div><h2>Students Corner</h2><div className="link-list">{studentCorner.map(([label, path]) => <Link key={path} to={path}>{label}</Link>)}</div></div><div><h2>Latest News</h2>{news.map((item) => <Link className="news-row" key={item.id} to={`/news/${item.id}`}><img src={item.image} alt="" /><span>{item.title}<small>{item.summary}</small></span></Link>)}</div></div></section>
      <section className="section muted"><div className="container"><h2>Photo Gallery</h2><div className="gallery-grid small">{photos.slice(0, 4).map((p) => <img key={p.id} src={p.src} alt={p.title} />)}</div></div></section>
    </>
  );
}
