import PageHeader from "../components/common/PageHeader.jsx";
import SEO from "../components/common/SEO.jsx";
import { TeacherCard } from "../components/common/Cards.jsx";
import { institution } from "../data/site.js";
import { people, teachers } from "../data/mockData.js";

const text = {
  history: ["History", `EXPERT COACHING CENTER was established in ${institution.established} at ${institution.address}. The center focuses on regular classes, assessment reports, guardian communication, and student discipline.`],
  "institution-details": ["Institution Details", `Name: ${institution.name}. Address: ${institution.address}. Phone: ${institution.phone}. Email: ${institution.email}. Year of Establishment: ${institution.established}.`],
  committee: ["Committee Members", "A public committee listing with academic advisors, guardian representatives, and management members can be connected to the backend later."],
  staff: ["Staff List", "Office assistants, support staff, and academic coordinators help maintain daily operations and student services."],
};

export function AboutText({ type }) {
  const [title, body] = text[type] || ["About", "Institution information."];
  return <><SEO title={title} /><PageHeader title={title} eyebrow="About" description={body} /><section className="section"><div className="container prose"><p>{body}</p><ol><li>Transparent academic planning</li><li>Regular guardian communication</li><li>Student-focused coaching environment</li></ol></div></section></>;
}

export function ProfilePage({ type }) {
  const person = people[type];
  return <><SEO title={person.position} /><PageHeader title={person.position} eyebrow="Management" description={person.message} /><section className="section"><div className="container message large"><img src={`https://placehold.co/260x300/e8f2ee/173d33?text=${encodeURIComponent(person.name)}`} alt={person.name} /><div><h2>{person.name}</h2><p className="badge">{person.position}</p><p>{person.message}</p><p>Educational background and detailed biography are represented as public placeholder content until connected with verified institutional records.</p></div></div></section></>;
}

export function TeachersPage() {
  return <><SEO title="Teachers" /><PageHeader title="Teachers" eyebrow="About" description="Complete public teacher directory." /><section className="section"><div className="container card-grid">{teachers.map((t) => <TeacherCard key={t.id} teacher={t} />)}</div></section></>;
}
