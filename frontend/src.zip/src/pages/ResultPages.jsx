import { useState } from "react";
import PageHeader from "../components/common/PageHeader.jsx";
import SEO from "../components/common/SEO.jsx";
import { result } from "../data/mockData.js";
import { Table } from "./AcademicPages.jsx";

function SearchPanel({ onSearch, fields = ["Student ID", "Roll", "Session", "Exam"] }) {
  return <div className="form-grid">{fields.map((f) => <label key={f}>{f}<input placeholder={f} /></label>)}<button className="btn primary" onClick={onSearch}>Search</button></div>;
}

export function IndividualResultPage() {
  const [show, setShow] = useState(false);
  return <><SEO title="Individual Academic Result" /><PageHeader title="Individual Academic Result" eyebrow="Result" /><section className="section printable"><div className="container"><div className="no-print"><SearchPanel onSearch={() => setShow(true)} /></div>{show && <ResultSheet />}</div></section></>;
}
export function AssessmentPage() {
  const [show, setShow] = useState(false);
  return <><SEO title="Assessment Reports" /><PageHeader title="Assessment Reports" eyebrow="Result" /><section className="section"><div className="container"><SearchPanel onSearch={() => setShow(true)} fields={["Student", "Class", "Session", "Assessment"]} />{show && <div className="card"><h2>Assessment Summary</h2><Table cols={["Subject","Marks","Grade","Teacher Remarks"]} rows={result.subjects.map((s) => [s[0], s[2], s[3], "Good progress; keep practicing."])} /></div>}</div></section></>;
}
export function BoardResultPage() {
  return <><SEO title="Board Result" /><PageHeader title="Board Result" eyebrow="Result" /><section className="section"><div className="container stats"><article className="card"><h3>Board</h3><p>Jashore</p></article><article className="card"><h3>Pass Rate</h3><p>96%</p></article><article className="card"><h3>GPA-5</h3><p>38</p></article><article className="card"><h3>Total</h3><p>142 Students</p></article></div></section></>;
}
function ResultSheet() {
  return <div className="result-sheet"><h2>Academic Transcript</h2><p>{result.student} • ID {result.studentId} • Class {result.className} • Roll {result.roll}</p><Table cols={["Subject","Full Marks","Obtained","Grade","GP"]} rows={result.subjects} /><div className="result-total"><strong>Total: {result.total}</strong><strong>GPA: {result.gpa} ({result.grade})</strong><strong>{result.status}</strong></div><button className="btn no-print" onClick={() => window.print()}>Print Result</button></div>;
}
