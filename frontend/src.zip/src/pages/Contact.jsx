import { useState } from "react";
import PageHeader from "../components/common/PageHeader.jsx";
import SEO from "../components/common/SEO.jsx";
import { institution } from "../data/site.js";

export default function Contact() {
  const [sent, setSent] = useState(false);
  return <><SEO title="Contact" /><PageHeader title="Contact Us" eyebrow="Contact" /><section className="section"><div className="container two-cols"><form className="card form-grid" onSubmit={(e) => { e.preventDefault(); setSent(true); }}><label>Name<input required /></label><label>Email<input type="email" required /></label><label>Mobile<input required /></label><label>Subject<input required /></label><label className="full">Message<textarea required /></label><button className="btn primary">Submit</button>{sent && <p className="success-text">Your message has been submitted successfully.</p>}</form><div className="card"><h2>Company Name: {institution.name}</h2><p>Email: {institution.email}</p><p>Mobile: {institution.phone}</p><p>Year Of Establish: {institution.established}</p><p>Address: {institution.address}</p><div className="map">Google Maps section</div></div></div></section></>;
}
