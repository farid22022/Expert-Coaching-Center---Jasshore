import { useMemo, useState } from "react";
import PageHeader from "../components/common/PageHeader.jsx";
import SEO from "../components/common/SEO.jsx";
import { students, routines, examRoutine, holidays } from "../data/mockData.js";

function FilterInput({ value, setValue, placeholder = "Search" }) { return <input value={value} onChange={(e) => setValue(e.target.value)} placeholder={placeholder} />; }

export function StudentsPage() {
  const [q, setQ] = useState("");
  const filtered = useMemo(() => students.filter((s) => Object.values(s).join(" ").toLowerCase().includes(q.toLowerCase())), [q]);
  return <><SEO title="Student List" /><PageHeader title="Student List" eyebrow="Academic" description="Search public mock student records without exposing private information." /><section className="section"><div className="container"><div className="filters"><FilterInput value={q} setValue={setQ} placeholder="Search by name, ID, class, section" /><button onClick={() => setQ("")}>Reset</button></div><Table cols={["Student ID","Name","Class","Section","Roll","Session","Shift"]} rows={filtered.map((s) => [s.id,s.name,s.className,s.section,s.roll,s.session,s.shift])} /></div></section></>;
}

export function ClassRoutinePage() {
  return <Routine title="Class Routine" data={routines} cols={["Day","Period","Start","End","Subject","Teacher","Room"]} map={(r) => [r.day,r.period,r.start,r.end,r.subject,r.teacher,r.room]} />;
}
export function ExamRoutinePage() {
  return <Routine title="Exam Routine" data={examRoutine} cols={["Exam","Class","Subject","Date","Start","End","Room"]} map={(r) => [r.exam,r.className,r.subject,r.date,r.start,r.end,r.room]} />;
}
function Routine({ title, data, cols, map }) {
  const [q, setQ] = useState("");
  const filtered = data.filter((r) => Object.values(r).join(" ").toLowerCase().includes(q.toLowerCase()));
  return <><SEO title={title} /><PageHeader title={title} eyebrow="Academic" description="Filter by session, shift, class, section, subject, or teacher." /><section className="section printable"><div className="container"><div className="filters no-print"><FilterInput value={q} setValue={setQ} placeholder="Filter routine" /><button onClick={() => window.print()}>Print</button></div><Table cols={cols} rows={filtered.map(map)} /></div></section></>;
}

export function RulesPage() {
  const rules = ["Attend classes on time and maintain at least 80% attendance.","Bring required books, copies, and class materials.","Respect teachers, staff, classmates, and campus property.","Follow examination rules and avoid unfair means.","Wear clean and appropriate uniform during class days."];
  return <><SEO title="Rules & Regulations" /><PageHeader title="Rules & Regulations" eyebrow="Academic" /><section className="section"><div className="container accordion">{rules.map((r, i) => <details key={r} open={i===0}><summary>Rule {i+1}</summary><p>{r}</p></details>)}</div></section></>;
}
export function UniformPage() {
  return <><SEO title="Uniform Details" /><PageHeader title="Uniform Details" eyebrow="Academic" /><section className="section"><div className="container card-grid"><article className="card"><h3>Boys Uniform</h3><p>Clean shirt, trousers, shoes, and institution-approved accessories.</p></article><article className="card"><h3>Girls Uniform</h3><p>Modest institution-approved dress, shoes, and seasonal requirements.</p></article><article className="card"><h3>Seasonal</h3><p>Winter sweater or jacket may be worn according to weather and notice.</p></article></div></section></>;
}
export function HolidaysPage() {
  return <><SEO title="List of Holidays" /><PageHeader title="List of Holidays" eyebrow="Academic" /><section className="section"><div className="container"><Table cols={["Date","Day","Holiday","Description"]} rows={holidays.map((h) => [h.date,h.day,h.title,h.description])} /></div></section></>;
}

export function Table({ cols, rows }) {
  return <div className="table-wrap"><table><thead><tr>{cols.map((c) => <th key={c}>{c}</th>)}</tr></thead><tbody>{rows.length ? rows.map((row, i) => <tr key={i}>{row.map((cell, j) => <td key={j}>{cell}</td>)}</tr>) : <tr><td colSpan={cols.length}>No records available.</td></tr>}</tbody></table></div>;
}
