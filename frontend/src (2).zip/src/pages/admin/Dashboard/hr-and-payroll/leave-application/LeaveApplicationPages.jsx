import { HrPayrollPageShell } from "../hrPayrollShared.jsx";

export function LeaveApplicationCreatePage() {
  return <HrPayrollPageShell title="Leave Application Create" />;
}

export function LeaveApplicationListPage() {
  return <HrPayrollPageShell title="Leave Application List" />;
}
