import { HrPayrollPageShell } from "../hrPayrollShared.jsx";

export function SalaryCreatePage() {
  return <HrPayrollPageShell title="Salary Create" />;
}

export function SalaryListPage() {
  return <HrPayrollPageShell title="Salary List" />;
}
